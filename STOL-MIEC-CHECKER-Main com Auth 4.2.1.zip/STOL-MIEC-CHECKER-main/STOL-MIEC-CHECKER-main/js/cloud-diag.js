/* Cloud status + test button */
(function(){
  const s = document.getElementById('cloudStatus');
  const t = document.getElementById('cloudTestBtn');
  function setSt(text, cls){ if(!s) return; s.textContent=text; s.className=cls||''; }
  async function upd(){
    try{
      if(!window.supa || !window.supa.ready()){ setSt('Cloud: OFF','bad'); return; }
      const { user } = await window.supa.getUser();
      if(user) setSt('Cloud: ON — '+(user.email||'sessão ativa'),'ok');
      else setSt('Cloud: ON — sem sessão','warn');
    }catch(e){ setSt('Cloud: erro','bad'); }
  }
  async function test(){
    try{
      if(!window.supa || !window.supa.ready()) throw new Error('Supabase não configurado');
      const { user } = await window.supa.getUser(); if(!user) throw new Error('Sem sessão');
      const ts=new Date().toISOString();
      await window.supa.saveHIN({hin:'TEST-'+ts,result_ok:true,details:['diag',ts],pre1998:false,cert:false});
      await window.supa.saveEngine({brand:'DIAG',payload:{ping:true,ts},result_ok:true,details:['diag',ts]});
      alert('✅ Teste gravado. Veja os Históricos.'); upd();
    }catch(e){ alert('❌ Falha: '+(e.message||e)); }
  }
  if(t) t.addEventListener('click', test);
  setTimeout(upd, 400);
  window.MIEC_updateCloudStatus = upd;
})();
// Copy to js/config.js (or use config.html to override in localStorage)
window.MIEC_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",
  STORAGE_BUCKET: "photos",
  ALLOW_DOMAIN: ""
};
# Security Policy
Se suspeitar de vulnerabilidade, reporte em privado para a equipa da PM (UCI Criminal).
Não abrir issues públicas com detalhes sensíveis.

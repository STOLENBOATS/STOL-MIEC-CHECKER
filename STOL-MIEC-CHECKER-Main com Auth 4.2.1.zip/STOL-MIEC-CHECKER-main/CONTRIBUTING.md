# Contribuir
- Branch principal: `main`
- Branch de releases: `release`
- Fluxo:
  1. `git checkout -b feat/nome`
  2. Pull Request para `main` (CI deve passar)
  3. Merge → tag `vX.Y.Z` em `release`

Texto PT/EN nos UI elements. Testar em modo Dia/Noite.
